% Directory containing the .tif images
folder = '/Users/rileymoeykens/Desktop/threshold_analysis';

files = dir(fullfile(folder, '*.tif'));

thresholds = [];
blackPixelCounts = [];

for k = 1:length(files)
    filename = files(k).name;
    filepath = fullfile(folder, filename);
    
    tokens = regexp(filename, 'threshold_(\d+)', 'tokens');
    if isempty(tokens)
        continue;
    end
    thresholdValue = str2double(tokens{1}{1});
    
    img = imread(filepath);
    img = logical(img);
    
    [rows, cols] = size(img);
    
    boundary = round(black_boundary(:));
    boundary(boundary < 1) = 0;
    boundary(boundary > cols) = cols;
    
    colIdx = 1:cols;
    leftMask = colIdx <= boundary;
    
    % Count black pixels in region
    blackPixels = nnz(~img & leftMask);
    
    % Correct normalization: ONLY pixels that exist in region
    totalLeftPixels = sum(boundary);
    
    thresholds(end+1) = thresholdValue;
    blackPixelCounts(end+1) = blackPixels / totalLeftPixels;
end

[thresholds, idx] = sort(thresholds);
blackPixelCounts = blackPixelCounts(idx);

%%
figure;
plot(thresholds, blackPixelCounts, '-o', 'LineWidth', 2);
xlabel('Threshold Value');
ylabel('Fraction White Pixels');
ylim([-0.05, 1])
grid on;

exportgraphics(gcf, ...
    '/Users/rileymoeykens/Desktop/RAC/Figures_for_pub/threshold_sensitivity_analysis/threshold_analysis.pdf', ...
    'ContentType', 'vector')
%%
figure;
plot(thresholds, blackPixelCounts, '-o', 'LineWidth', 2);
xlabel('Threshold Value');
ylabel('Fraction White Pixels');
xlim([79, 97])
ylim([0.001, 0.015])
grid on;


exportgraphics(gcf, ...
    '/Users/rileymoeykens/Desktop/RAC/Figures_for_pub/threshold_sensitivity_analysis/threshold_analysis_zoomedin.pdf', ...
    'ContentType', 'vector')

